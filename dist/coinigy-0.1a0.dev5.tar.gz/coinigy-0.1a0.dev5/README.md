# Coinigy API

Fork of Coinigy API examples. Python bindings for Coinigy API functions. Not much more than the original examples with a cleaned-up working directory and packaged as installer with setuptools.

--------


Here you will find issue tracking, docs, and code examples for all Coinigy developer APIs



REST HTTP API docs located here: http://docs.coinigy.apiary.io/#reference

WEBSOCKET API docs located here: Coming soon!

WEBSOCKET SERVER INFO:

HOST: sc-02.coinigy.com*

PORT: 443

SECURE: true


WEBSOCKET CLIENTS:

https://github.com/SocketCluster/client-drivers

*If your client requires the full wss url for websockets, use: wss://sc-02.coinigy.com/socketcluster/
