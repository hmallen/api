from .coinigy import Coinigy
from .coinigy import CoinigyV2
