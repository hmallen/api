from .coinigy import CoinigyREST
